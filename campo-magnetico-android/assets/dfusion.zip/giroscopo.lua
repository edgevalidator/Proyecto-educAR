Giroscopo = { name = '' , animated = false, direction = 'counterclockwise', precesion = 'quick' }

function Giroscopo:new(o)
	o = o or {}
	setmetatable(o, self)
	self.__index = self
	o:loadModel()
	return o
end

function Giroscopo:getName()
	return self.name
end

function Giroscopo:getAnimated()
	return self.animated
end

function Giroscopo:getAnimated()
	return self.animated
end

function Giroscopo:getDirection()
	return self.direction
end

function Giroscopo:setDirection(value)
	self.direction = value
end

function Giroscopo:getPrecesion()
	return self.precesion
end

function Giroscopo:setPrecesion(value)
	self.precesion = value
end

function Giroscopo:getNameForModel()
	return "model-" .. self:getName()
end

function Giroscopo:getScaleForModel()
	if (getOSType() == TI_OS_ANDROID) then
		return 0.400
	else
		return 0.500
	end
end

function Giroscopo:getNameForStaticModel()
	return "static-" .. self:getName()
end

function Giroscopo:getNameForAnimatedModel(clockwise, quick)
	local aux = "animated-"
	return aux .. self:getName()
end

function Giroscopo:getNameForVectors(clockwise, quick)
	local aux = "vectors-"
	return aux .. self:getName()
end

function Giroscopo:getNameForVectorGroup(clockwise, quick, group_name)
	local aux = "vectorgroup-"
	return aux .. self:getName() .. "-" .. group_name
end

function Giroscopo:setVisibility(visibility)

	local model_name = self:getNameForModel()
	local model = Object3D(getCurrentScene():getObjectByName(model_name))
	model:setVisible(visibility)
	
end

function Giroscopo:switchVectorsVisibility()

	local f = function(obj_name)
		obj = Object3D(getCurrentScene():getObjectByName(obj_name))
		if obj:getVisible() then
			obj:setVisible(false)
		else
			obj:setVisible(true)
		end
	end

	f(self:getNameForVectors(false, false))
	
end

function Giroscopo:switchVectorGroupVisibility(group)

	local f = function(obj_name)
		local obj = Scenette(getCurrentScene():getObjectByName(obj_name))
		if obj:getVisible() then
			obj:setVisible(false)
		else
			obj:setVisible(true)
		end
	end

	f(self:getNameForVectorGroup(false, false, group))
	
end

function Giroscopo:loadModel()
	local scene = getCurrentScene()
	local ref = Object3D(scene:getObjectByName("ref"))
	
	local model = Object3D(scene:createObject(CID_OBJECT3D))
	ref:addChild(model)
	model:setName(self:getNameForModel())
	model:setVisible(false)
	model:setOrientationEuler(90.0, 0.0, 0.0)
	model:setScale(self:getScaleForModel())
	
	local fLoadStaticModel = function(model)
		local static_model = Scenette(scene:createObject(CID_SCENETTE))	
		model:addChild(static_model)
		static_model:setName(self:getNameForStaticModel())
		static_model:setResource("modelos/" .. self:getName() .. "/" .. self:getName() .. ".scene")	
		static_model:setVisible(true)
	end
	
	local fLoadAnimatedModel = function(model, clockwise, quick)
		local animated_model = Scenette(scene:createObject(CID_SCENETTE))
		model:addChild(animated_model)
		animated_model:setName(self:getNameForAnimatedModel(clockwise, quick))
		local resource = "modelos/" .. self:getName() .. "/"
		resource = resource .. self:getName() .. "/" .. self:getName() .. ".scene"
		animated_model:setResource(resource)
		animated_model:setVisible(true)
		
		-- Load vectors
		local vectors = Object3D(scene:createObject(CID_OBJECT3D))
		animated_model:addChild(vectors)
		vectors:setName(self:getNameForVectors(clockwise, quick))
		vectors:setVisible(false)
		vectors:setOrientationEuler(90.0, 0.0, 0.0)
		
		-- Load vector groups
		local aux = { "linea_1", "linea_2", "linea_3", "linea_4" }
		for i = 1, 4 do
			local vector_group = Scenette(scene:createObject(CID_SCENETTE))
			vectors:addChild(vector_group)
			vector_group:setName(self:getNameForVectorGroup(clockwise, quick, aux[i]))
			local resource = "modelos/" .. self:getName() .. "/"
			resource = resource .. aux[i] .. "/" .. aux[i] .. ".scene"
			vector_group:setResource(resource)
			vector_group:setVisible(true)		
		end
	end
	
	fLoadAnimatedModel(model, false, false)
	
end


--  ECUACIONES

Ecuaciones = { }

function Ecuaciones:new(o)
	o = o or {}
	setmetatable(o, self)
	self.__index = self
	o:loadModel()
	return o
end

function Ecuaciones:getNameForModel()
	return "equations"
end

function Ecuaciones:getScaleForModel()
	return 0.245
end

function Ecuaciones:setVisibility(visibility)

	local model_name = self:getNameForModel()
	local model = Scenette(getCurrentScene():getObjectByName(model_name))
	model:setVisible(visibility)
	
end

function Ecuaciones:loadModel()

	local scene = getCurrentScene()
	local ref = Object3D(scene:getObjectByName("ref"))
	
	local model = Scenette(scene:createObject(CID_SCENETTE))
	ref:addChild(model)
	model:setName(self:getNameForModel())
	model:setResource("ecuacion/ecuacion.scene")	
	model:setVisible(false)
	model:setOrientationEuler(90.0, 0.0, 0.0)
	model:setScale(self:getScaleForModel())
	
end

--  NOTAS

Notas = { length = {0, 0, 0, 0, 0, 0, 0, 0, 0}, current = 0, excercise = 0}

function Notas:new(o)
	o = o or {}
	setmetatable(o, self)
	self.__index = self
	o:loadModel()
	return o
end

function Notas:getNameForModel()
	return "notes"
end

function Notas:getScaleForModel()
	return 0.245
end

function Notas:setExcercise(e)
	self.excercise = e
	if self.length[e] == 0 then
		self.current = 0
	else
		self.current = 1		
	end
	
	self:changeMaterial(self.excercise, self.current)
end

function Notas:setVisibility(visibility)

	local model_name = self:getNameForModel()
	local model = Scenette(getCurrentScene():getObjectByName(model_name))
	model:setVisible(visibility)
	
end

function Notas:isVisible()

	local model_name = self:getNameForModel()
	local model = Scenette(getCurrentScene():getObjectByName(model_name))
	return model:getVisible()

end

function Notas:showPrevious()

	if self.length[self.excercise] > 0 then
		self.current = self.current - 1
	end
	
	if self.length[self.excercise] < 1 then
		self.current = self.length
	end

	if not self.length[self.excercise] == 0 then
		self:changeMaterial(self.excercise, self.current)
	end
	
end

function Notas:showNext()
	if self.length[self.excercise] > 0 then
		self.current = self.current + 1
	end
	
	if self.current > self.length[self.excercise] then
		self.current = 1
	end
	
	if not (self.length[self.excercise] == 0) then
		self:changeMaterial(self.excercise, self.current)
	else
		self.current = 0
	end

end

function Notas:changeMaterial(e, i)
	local scene = getCurrentScene()
	
	local texture = Texture(scene:createObject(CID_TEXTURE))
	if i == 0 or e == 0 then
		texture:setResource("notas/nota/nota.png")
	else
		texture:setResource("notas/" .. e .. "/nota_" .. i .. ".png")
	end
	
	local material = getMaterial("nota/Material26")
	material:setTexture(texture)

end

function Notas:loadModel()

	local scene = getCurrentScene()
	local ref = Object3D(scene:getObjectByName("ref"))
	
	local model = Scenette(scene:createObject(CID_SCENETTE))
	ref:addChild(model)
	model:setName(self:getNameForModel())
	model:setResource("notas/nota/nota.scene")	
	model:setVisible(false)
	model:setOrientationEuler(90.0, 0.0, 0.0)
	model:setScale(self:getScaleForModel())
	
end


--  Soluciones

Soluciones = { excercise = 0 }

function Soluciones:new(o)
	o = o or {}
	setmetatable(o, self)
	self.__index = self
	o:loadModel()
	return o
end

function Soluciones:getNameForModel()
	return "solutions"
end

function Soluciones:getScaleForModel()
	return 0.245
end

function Soluciones:setExcercise(e)
	self.excercise = e
	
	self:changeMaterial(self.excercise, false)
end

function Soluciones:disclose()
	self:changeMaterial(self.excercise, true)
end

function Soluciones:setVisibility(visibility)

	local model_name = self:getNameForModel()
	local model = Scenette(getCurrentScene():getObjectByName(model_name))
	model:setVisible(visibility)
	
end

function Soluciones:isVisible()

	local model_name = self:getNameForModel()
	local model = Scenette(getCurrentScene():getObjectByName(model_name))
	return model:getVisible()

end

function Soluciones:changeMaterial(e, show)
	local scene = getCurrentScene()
	
	local texture = Texture(scene:createObject(CID_TEXTURE))
	if e == 0 or not show then
		texture:setResource("soluciones/solucion/solucion.png")
	else
		texture:setResource("soluciones/solucion_" .. e .. ".png")
	end
	
	local material = getMaterial("solucion/solucion")
	material:setTexture(texture)

end

function Soluciones:loadModel()

	local scene = getCurrentScene()
	local ref = Object3D(scene:getObjectByName("ref"))
	
	local model = Scenette(scene:createObject(CID_SCENETTE))
	ref:addChild(model)
	model:setName(self:getNameForModel())
	model:setResource("soluciones/solucion/solucion.scene")	
	model:setVisible(false)
	model:setOrientationEuler(90.0, 0.0, 0.0)
	model:setScale(self:getScaleForModel())
	
end

-- VIDEOS

if (getOSType() == TI_OS_ANDROID) then
	Videos = { length = 0, current = 0 }
else
	Videos = { length = 0, current = 0 }
end

function Videos:new(o)
	o = o or {}
	setmetatable(o, self)
	self.__index = self
	o:loadModel()
	return o
end

function Videos:getNameForModel()
	return "video"
end

function Videos:getNameForVideoCapture(i)
	return "video-capture-" .. i
end

function Videos:getScaleForModel()
	return 0.245
end

function Videos:setVisibility(visibility)

	local model_name = self:getNameForModel()
	local model = Scenette(getCurrentScene():getObjectByName(model_name))
	local oldState = model:getVisible()
	model:setVisible(visibility)
	
	if visibility and not oldState then
		self:play()
	else
		self:stop()
	end
end

function Videos:isVisible()

	local model_name = self:getNameForModel()
	local model = Scenette(getCurrentScene():getObjectByName(model_name))
	return model:getVisible()

end

function Videos:showPrevious()

	if (self.length > 0) then
		self:close()
	end
	
	if self.length > 0 then
		self.current = self.current - 1
	end
	
	if self.current < 1 then
		self.current = self.length
	end

	if (self.length > 0) then
		self:changeMaterial(self.current)
	end
	
end

function Videos:showNext()

	if (self.length > 0) then
		self:close()
	end
	
	if self.length > 0 then
		self.current = self.current + 1
	end
	
	if self.current > self.length then
		self.current = 1
	end
	
	if (self.length > 0) then
		self:changeMaterial(self.current)
	end

end

function Videos:close()
	if (self.length > 0) then
		local scene = getCurrentScene()
		local video_capture = VideoCapture(scene:getObjectByName(self:getNameForVideoCapture(self.current)))
		video_capture:pause()
		video_capture:close()
	end
end

function Videos:changeMaterial(i)	
	local scene = getCurrentScene()
	
	local video_capture = VideoCapture(scene:getObjectByName(self:getNameForVideoCapture(self.current)))
	video_capture:open()
				
	local video_texture = VideoTexture(scene:createObject(CID_VIDEOTEXTURE))
	video_texture:setVideoCapture(video_capture)

	local material = getMaterial("video/Material27")
	material:setTexture(video_texture)
end

function Videos:play()
	if (self.length > 0) then
		local scene = getCurrentScene()
		local video_capture = VideoCapture(scene:getObjectByName(self:getNameForVideoCapture(self.current)))

		video_capture:play(0)
	end
end

function Videos:stop()
	if (self.length > 0) then
		local scene = getCurrentScene()
		local video_capture = VideoCapture(scene:getObjectByName(self:getNameForVideoCapture(self.current)))

		video_capture:pause()
	end
end

function Videos:switchPlayingState()
	local scene = getCurrentScene()
	local video_capture = VideoCapture(scene:getObjectByName(self:getNameForVideoCapture(self.current)))
	if (self.length > 0) then
		if video_capture:isPaused() then
			video_capture:play()
		else
			video_capture:pause()
		end
	end
end

function Videos:loadModel()
	local scene = getCurrentScene()
	local ref = Object3D(scene:getObjectByName("ref"))
	
	local model = Scenette(scene:createObject(CID_SCENETTE))
	ref:addChild(model)
	model:setName(self:getNameForModel())
	model:setResource("videos/video/video.scene")
	model:setVisible(false)
	model:setOrientationEuler(90.0, 0.0, 0.0)
	model:setScale(self:getScaleForModel())
	
	if self.length > 0 then
		for i = 1, self.length do
			local video_capture = VideoCapture(scene:createObject(CID_VIDEOCAPTURE))
			video_capture:setName(self:getNameForVideoCapture(i))
			video_capture:setResource("videos/video_" .. i .. ".xml")
		end
		self:changeMaterial(self.current)
	end
	
end


-- BOTONES

Boton = { id = "", filename = "" }

function Boton:new(o)
	o = o or {}
	setmetatable(o, self)
	self.__index = self
	o:loadModel()
	return o
end

function Boton:getNameForModel()
	return self.id
end

function Boton:getScaleForModel()
	if (getOSType() == TI_OS_ANDROID) then
		return 0.300
	else
		return 0.150
	end
end

function Boton:getVerticalOffsetForModel()
	if (getOSType() == TI_OS_ANDROID) then
		return -12.0
	else
		return -8.1
	end
end

function Boton:isAnimationInState(state)
	
	local obj = Scenette(getCurrentScene():getObjectByName(self:getNameForModel()))
	local animation = obj:getAnimation(0)
	if not animation:isNull() then
		if ((state == "on") and not(animation:getTimePosition() == 0 or animation:getTimePosition() == 1)) then
			return true
		elseif ((state == "off") and not(animation:getTimePosition() == 0.5)) then
			return true
		elseif (not state == "on" and not state == "off") then
			-- Esto se da en botones que bajan y suben en seguida
			return true
		else
			return false
		end
	end
		
end

function Boton:playAnimation(state)
	
	local obj = Scenette(getCurrentScene():getObjectByName(self:getNameForModel()))
	local animation = obj:getAnimation(0)
	if not animation:isNull() then
		if ((state == "on") and (animation:getTimePosition() == 0 or animation:getTimePosition() == 1)) then
			animation:play(0,0.5)			
		elseif ((state == "off") and (animation:getTimePosition() == 0.5)) then
			animation:play(0.5,1)
		elseif (not (state == "on") and not (state == "off")) then
			animation:play(0,0.5)
		end
	end
		
end

function Boton:switchAnimation()

	local obj = Scenette(getCurrentScene():getObjectByName(self:getNameForModel()))
	local animation = obj:getAnimation(0)
	
	if not animation:isNull() then
		if animation:getTimePosition() == 0 or animation:getTimePosition() == 1 then
			animation:play(0,0.5)			
		else
			animation:play(0.5,1)
		end
	end
	
end

function Boton:loadModel()

	local scene = getCurrentScene()
	local ref = Object3D(scene:getObjectByName("ref"))
	
	local model = Scenette(scene:createObject(CID_SCENETTE))
	ref:addChild(model)
	model:setName(self:getNameForModel())
	model:setResource("tablero/" .. self.filename .. "/" .. self.filename .. ".scene")	
	model:setVisible(true)
	model:setOrientationEuler(90.0, 0.0, 0.0)
	model:setPosition(0.0, self:getVerticalOffsetForModel(), 0.0)
	model:setScale(self:getScaleForModel())
end

-- DISPLAY

Display = { current = 0, length = 9 }

function Display:new(o)
	o = o or {}
	setmetatable(o, self)
	self.__index = self
	o:loadModel()
	return o
end

function Display:getNameForModel()
	return "display"
end

function Display:getScaleForModel()
	if (getOSType() == TI_OS_ANDROID) then
		return 0.300
	else
		return 0.150
	end
end

function Display:getVerticalOffsetForModel()
	if (getOSType() == TI_OS_ANDROID) then
		return -12.0
	else
		return -8.1
	end
end

function Display:changePosition(number)
	local obj = Scenette(getCurrentScene():getObjectByName(self:getNameForModel()))
	local animation = obj:getAnimation(0)
	
	if not animation:isNull() then
		animation:setLoop(false)
		animation:play()
		animation:setTimePosition(number * 2 / 30)
		animation:pause()
	end
end

function Display:getCurrent()
	return self.current
end

function Display:reset()
	self.current = 0
	self:changePosition(self.current)
end

function Display:showPrevious()

	if self.length > 0 then
		self.current = self.current - 1
	end
	
	if self.current < 1 then
		self.current = self.length
	end

	self:changePosition(self.current)
	
end

function Display:showNext()

	if self.length > 0 then
		self.current = self.current + 1
	end
	
	if self.current > self.length then
		self.current = 1
	end
	
	self:changePosition(self.current)

end

function Display:loadModel()

	local scene = getCurrentScene()
	local ref = Object3D(scene:getObjectByName("ref"))
	
	local model = Scenette(scene:createObject(CID_SCENETTE))
	ref:addChild(model)
	model:setName(self:getNameForModel())
	model:setResource("tablero/display/display.scene")	
	model:setVisible(true)
	model:setOrientationEuler(90.0, 0.0, 0.0)
	model:setPosition(0.0, self:getVerticalOffsetForModel(), 0.0)
	model:setScale(self:getScaleForModel())
end

-- TABLERO

function loadTablero()
	local scene = getCurrentScene()
	local ref = Object3D(scene:getObjectByName("ref"))
	
	local model = Scenette(scene:createObject(CID_SCENETTE))
	ref:addChild(model)
	model:setName("tablero")
	model:setResource("tablero/tablero/tablero.scene")	
	model:setVisible(true)
	model:setOrientationEuler(90.0, 0.0, 0.0)
	if (getOSType() == TI_OS_ANDROID) then
		model:setPosition(0.0, -12.0, 0.0)
	else
		model:setPosition(0.0, -8.1, 0.0)
	end
	if (getOSType() == TI_OS_ANDROID) then
		model:setScale(0.300)
	else
		model:setScale(0.150)
	end
end

loadTablero()

local giroscopo_01 = Giroscopo:new{name="rectoinf", animated=true}
local giroscopo_02 = Giroscopo:new{name="espira", animated=true}
local giroscopo_04 = Giroscopo:new{name="toride2", animated=true}
local notas = Notas:new{}
local soluciones = Soluciones:new{}
local videos = Videos:new{}
local ecuaciones = Ecuaciones:new{}

local boton_01 = Boton:new{id="boton_01", filename="btn_c01" }
local boton_02 = Boton:new{id="boton_02", filename="btn_c02" }
local boton_04 = Boton:new{id="boton_04", filename="btn_c03" }
local boton_vectores = Boton:new{id="boton_lineas", filename="llave_Lineas" }
local boton_ecuaciones = Boton:new{id="boton_ecuaciones", filename="btn_Ecuacion" }
local boton_lineas1 = Boton:new{id="boton_lineas1", filename="llave_1"}
local boton_lineas2 = Boton:new{id="boton_lineas2", filename="llave_2"}
local boton_lineas3 = Boton:new{id="boton_lineas3", filename="llave_3"}
local boton_lineas4 = Boton:new{id="boton_lineas4", filename="llave_4"}
boton_lineas1:playAnimation("on")
boton_lineas2:playAnimation("on")
boton_lineas3:playAnimation("on")
boton_lineas4:playAnimation("on")

function show_model(option)
	if option == 1 then
		boton_01:playAnimation("on")
		boton_02:playAnimation("off")
		boton_04:playAnimation("off")
		giroscopo_01:setVisibility(true)
		giroscopo_02:setVisibility(false)
		giroscopo_04:setVisibility(false)
	elseif option == 2 then	
		boton_01:playAnimation("off")
		boton_02:playAnimation("on")
		boton_04:playAnimation("off")
		giroscopo_01:setVisibility(false)
		giroscopo_02:setVisibility(true)
		giroscopo_04:setVisibility(false)
	elseif option == 4 then	
		boton_01:playAnimation("off")
		boton_02:playAnimation("off")
		boton_04:playAnimation("on")
		giroscopo_01:setVisibility(false)
		giroscopo_02:setVisibility(false)
		giroscopo_04:setVisibility(true)
	end
	boton_ecuaciones:playAnimation("off")	
	ecuaciones:setVisibility(false)
end

function show_equations()
	boton_01:playAnimation("off")
	boton_02:playAnimation("off")
	boton_04:playAnimation("off")
	
	boton_ecuaciones:playAnimation("on")
	
	giroscopo_01:setVisibility(false)
	giroscopo_02:setVisibility(false)
	giroscopo_04:setVisibility(false)
	ecuaciones:setVisibility(true)
end

function toggle_vectors()
	boton_vectores:switchAnimation()
	giroscopo_01:switchVectorsVisibility()
	giroscopo_02:switchVectorsVisibility()
	giroscopo_04:switchVectorsVisibility()
end

function toggle_vector_group(group)
	if group == 'lineas1' then
		boton_lineas1:switchAnimation()	
	elseif group == 'lineas2' then
		boton_lineas2:switchAnimation()
	elseif group == 'lineas3' then
		boton_lineas3:switchAnimation()
	elseif group == 'lineas4' then
		boton_lineas4:switchAnimation()
	end
	giroscopo_01:switchVectorGroupVisibility(group)
	giroscopo_02:switchVectorGroupVisibility(group)
	giroscopo_04:switchVectorGroupVisibility(group)
end