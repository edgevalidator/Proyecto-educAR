local im = getInputManager()
local scene = getCurrentScene()
local viewport = Viewport(scene:getObjectByName("viewport"))
local window = RenderWindow(scene:getMainView())
local touchscreen = nil
local touched = false
local mouse = nil

if isTouchScreenDeviceAvailable() then
	touchscreen = TouchScreen(im:getDevice(TIINPUT_TOUCHSCREENDEVICE))
	touchscreen:acquire()
else
	mouse = Mouse(im:getDevice(TIINPUT_MOUSEDEVICE))
end

repeat

	local action = ''

	isCommand, command = getComponentInterface():pullCommand()
	
	if isCommand then
	
		action = command["CommandName"]
		
	elseif (gtrackingStatus == 1) then			
		
		local obj = nil
		
		if touchscreen then
		
			local touches = touchscreen:getTouches()
			if (#touches > 0) then
				if not touched then
					local t = touches[1]
					obj = viewport:pick(t.position.x, t.position.y, false)
				end
				touched = true
			else
				touched = false
			end
			
		else
		
			if mouse:wasButtonReleased(TIMOUSE_RIGHTBUTTON) then
				err, RWX, RWY = window:getLocalCursorCoordinates()
				obj = viewport:pick(RWX, RWY, false)
			end
			
		end
		
		if obj and not obj:isNull() then
			action = obj:getName()
		end
		
	end
	
	if not (action == '') then
		if action == 'boton_01' then
			show_model(1)
		elseif action == 'boton_02' then
			show_model(2)
		elseif action == 'boton_04' then
			show_model(4)
		elseif action == 'boton_ecuaciones' then
			show_equations()
		elseif action == 'boton_lineas1' then
			toggle_vector_group('linea_1')
		elseif action == 'boton_lineas2' then
			toggle_vector_group('linea_2')
		elseif action == 'boton_lineas3' then
			toggle_vector_group('linea_3')
		elseif action == 'boton_lineas4' then
			toggle_vector_group('linea_4')
		elseif action == 'boton_lineas' then
			toggle_vectors()
		else
			LOG(action)
		end
	end

until coroutine.yield()